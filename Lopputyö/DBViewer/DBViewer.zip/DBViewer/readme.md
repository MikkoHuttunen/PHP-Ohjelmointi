<h1>DBViewer 1.0</h1>

Simple database viewer which helps you view your local databases and edit them.
If you need to change login info, you can edit connection.php.

Mikko Huttunen 2020
