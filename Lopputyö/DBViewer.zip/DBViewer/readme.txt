DBViewer

Simple database viewer which helps you view your local databases and edit them.

How to use:

Put DBViewer folder to your server and access it by opening it in your browser 'localhost/DBViewer/index.php'
If you need to edit login information, you can do so by editing connection.php.

Mikko Huttunen 2020
